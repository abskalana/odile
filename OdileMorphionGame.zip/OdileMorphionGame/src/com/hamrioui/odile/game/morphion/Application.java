package com.hamrioui.odile.game.morphion;

import javax.swing.JFrame;

import com.hamrioui.odile.game.morphion.view.Dashboard;

public class Application {

    public static void main(String[] args) {
    	Dashboard dashboardGame = new Dashboard();
    	dashboardGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	dashboardGame.setTitle("Jeu de morphion");
    	dashboardGame.setVisible(true);
    }
  
}