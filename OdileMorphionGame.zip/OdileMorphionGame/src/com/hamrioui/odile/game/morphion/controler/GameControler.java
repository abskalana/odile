package com.hamrioui.odile.game.morphion.controler;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.hamrioui.odile.game.morphion.model.Segment;
import com.hamrioui.odile.game.morphion.model.Joueur;
import com.hamrioui.odile.game.morphion.model.Option;
import com.hamrioui.odile.game.morphion.model.Resultat;
import com.hamrioui.odile.game.morphion.utils.Constants;

public class GameControler {
	
	private Joueur joueur;
	
	 public GameControler(Joueur joueur) {
		super();
		this.joueur = joueur;
	}
	 
	public  void addDroite(List<Point> line, int[] dir) {
	        Point p1 = line.get(0);
	        Point p2 = line.get(line.size() - 1);
	 
	        // mark end points for 5T
	        getJoueur().getPoints()[p1.y][p1.x] |= dir[1];
	        getJoueur().getPoints()[p2.y][p2.x] |= dir[1];
	 
	        getJoueur().getDroites().add(new Segment(p1, p2));
	 
	        for (Point px : line)
	        	getJoueur().getPoints()[px.y][px.x] |= dir[0];
	 
	        getJoueur().setMinC(Math.min(p1.x - 1, Math.min(p2.x - 1, getJoueur().getMinC())));
	        getJoueur().setMaxC(Math.max(p1.x + 1, Math.max(p2.x + 1, getJoueur().getMaxC())));
	        getJoueur().setMinR(Math.min(p1.y - 1, Math.min(p2.y - 1, getJoueur().getMinR())));
	        getJoueur().setMaxR(Math.max(p1.y + 1, Math.max(p2.y + 1, getJoueur().getMaxR())));
	    }
	   public void checkDroite(int dir, int end, int r, int c, int rIncr, int cIncr) {
	        List<Point> result = new ArrayList<>(5);
	        for (int i = -4; i < 1; i++) {
	            result.clear();
	            for (int j = 0; j < 5; j++) {
	                int y = r + rIncr * (i + j);
	                int x = c + cIncr * (i + j);
	                int p = getJoueur().getPoints()[y][x];
	                if (p != Constants.EMPTY && (p & dir) == 0 || (p & end) != 0 || i + j == 0)
	                    result.add(new Point(x, y));
	                else
	                    break;
	            }
	            if (result.size() == 5) {
	            	getJoueur().getCandidates().add(new Option(new ArrayList<>(result),
	                        new int[]{dir, end}));
	            }
	        }
	    }
	 
	    public  void checkLines(int r, int c) {
	    	getJoueur().getCandidates().clear();
	        checkDroite(Constants.HORI, Constants.HORI_END, r, c, 0, 1);
	        checkDroite(Constants.VERT, Constants.VERT_END, r, c, 1, 0);
	        checkDroite(Constants.DIUP, Constants.DIUP_END, r, c, -1, 1);
	        checkDroite(Constants.DIDO, Constants.DIDO_END, r, c, 1, 1);
	    }
	    
	    public void draw(Graphics2D g,int w, int h) {
	    	getJoueur().setCenterX(w / 2);
	    	getJoueur().setCenterY(h / 2);
	    	getJoueur().setOrigX(getJoueur().getCenterX() - getJoueur().getHalfCell() - 24 * getJoueur().getCellSize());
	    	getJoueur().setOrigY(getJoueur().getCenterY() - getJoueur().getHalfCell() - 24 * getJoueur().getCellSize());
	 
	        // grid
	        g.setColor(Color.lightGray);
	 
	        int x = (getJoueur().getCenterX() - getJoueur().getHalfCell()) % getJoueur().getCellSize();
	        int y = (getJoueur().getCenterY() - getJoueur().getHalfCell()) % getJoueur().getCellSize();
	 
	        for (int i = 0; i <= w / getJoueur().getCellSize(); i++)
	            g.drawLine(x + i * getJoueur().getCellSize(), 0, x + i * getJoueur().getCellSize(), h);
	 
	        for (int i = 0; i <= h / getJoueur().getCellSize(); i++)
	            g.drawLine(0, y + i * getJoueur().getCellSize(), w, y + i * getJoueur().getCellSize());
	 
	        // lines
	        g.setStroke(new BasicStroke(2));
	        for (int i = 0; i < getJoueur().getDroites().size(); i++) {
	            Segment line = getJoueur().getDroites().get(i);
	            if (i == getJoueur().getDroites().size() - 1)
	                g.setColor(new Color(0x3399FF));
	            else
	                g.setColor(Color.orange);
	            int x1 = getJoueur().getOrigX() + line.start.x * getJoueur().getCellSize();
	            int y1 = getJoueur().getOrigY() + line.start.y * getJoueur().getCellSize();
	            int x2 = getJoueur().getOrigX() + line.end.x * getJoueur().getCellSize();
	            int y2 = getJoueur().getOrigY() + line.end.y * getJoueur().getCellSize();
	            g.drawLine(x1, y1, x2, y2);
	        }
	 
	        // points
	        for (int r = getJoueur().getMinR(); r < getJoueur().getMaxR(); r++)
	            for (int c = getJoueur().getMinC(); c < getJoueur().getMaxC(); c++) {
	                int p = getJoueur().getPoints()[r][c];
	 
	                if (p == Constants.EMPTY)
	                    continue;
	 
	                if ((p & Constants.ORIG) != 0)
	                    g.setColor(Color.red);
	 
	                else if ((p & Constants.CAND) != 0)
	                    g.setColor(Color.green);
	 
	                else if ((p & Constants.HINT) != 0) {
	                    g.setColor(Color.lightGray);
	                    getJoueur().getPoints()[r][c] &= ~Constants.HINT;
	                } else
	                    g.setColor(Color.darkGray);
	 
	                drawPoint(g,c, r);
	            }
	    }
	 
	    private void drawPoint(Graphics2D g, int x, int y) {
	        x = getJoueur().getOrigX() + x * getJoueur().getCellSize() - (getJoueur().getPointSize() / 2);
	        y = getJoueur().getOrigY() + y * getJoueur().getCellSize() - (getJoueur().getPointSize() / 2);
	        g.fillOval(x, y, getJoueur().getPointSize(), getJoueur().getPointSize());
	    }
	 
	    public Resultat calculateMove(int r, int c) {
	        checkLines(r, c);
	        if (getJoueur().getCandidates().size() > 0) {
	            Option choice = getJoueur().getCandidates().get(0);
	            addDroite(choice.points, choice.dir);
	            return Resultat.BON;
	        }
	        return Resultat.MAUVAIS;
	    }
	 
	    public Resultat move(float x, float y) {
	        int r = Math.round((y - getJoueur().getOrigY()) / getJoueur().getCellSize());
	        int c = Math.round((x - getJoueur().getOrigX()) / getJoueur().getCellSize());
	 
	        if (c < getJoueur().getMinC() || c > getJoueur().getMaxC() || r < getJoueur().getMinR() || r > getJoueur().getMaxR())
	            return Resultat.MAUVAIS;
	 
	        int diffX = (int) Math.abs(x - (getJoueur().getOrigX() + c * getJoueur().getCellSize()));
	        int diffY = (int) Math.abs(y - (getJoueur().getOrigY() + r * getJoueur().getCellSize()));
	        if (diffX > getJoueur().getCellSize() / 5 || diffY > getJoueur().getCellSize() / 5)
	            return Resultat.MAUVAIS;
	 
	        if ((getJoueur().getPoints()[r][c] & Constants.CAND) != 0) {
	            Option choice = getJoueur().getOptions().get(new Point(c, r));
	            addDroite(choice.points, choice.dir);
	            for (Option ch : getJoueur().getOptions().values()) {
	                for (Point pt : ch.points)
	                	getJoueur().getPoints()[pt.y][pt.x] &= ~(Constants.CAND | Constants.ORIG);
	            }
	            getJoueur().getOptions().clear();
	            return Resultat.BON;
	        }
	 
	        if (getJoueur().getPoints()[r][c] != Constants.EMPTY || getJoueur().getOptions().size() > 0)
	            return Resultat.MAUVAIS;
	 
	        checkLines(r, c);
	 
	        if (getJoueur().getCandidates().size() == 1) {
	            Option choice = getJoueur().getCandidates().get(0);
	            addDroite(choice.points, choice.dir);
	            return Resultat.BON;
	        } else if (getJoueur().getCandidates().size() > 1) {
	        	
	        	getJoueur().getPoints()[r][c] |= Constants.ORIG;
	            for (Option ch : getJoueur().getCandidates()) {
	                List<Point> cand = ch.points;
	                Point pt = cand.get(cand.size() - 1);
	                if (pt.equals(new Point(c, r)))
	                    pt = cand.get(0);
	                getJoueur().getPoints()[pt.y][pt.x] |= Constants.CAND;
	                getJoueur().getOptions().put(pt, ch);
	            }
	            return Resultat.VILAIN;
	        }
	 
	        return Resultat.MAUVAIS;
	    }
	    
	    public List<Point> getPossibleMoves() {
	        List<Point> moves = new ArrayList<>();
	        for (int r = getJoueur().getMinR(); r < getJoueur().getMaxR(); r++)
	            for (int c = getJoueur().getMinC(); c < getJoueur().getMaxC(); c++) {
	                if (getJoueur().getPoints()[r][c] == Constants.EMPTY) {
	                	checkLines(r, c);
	                    if (getJoueur().getCandidates().size() > 0)
	                        moves.add(new Point(c, r));
	                }
	            }
	        return moves;
	    }
	    
	    public  final void start() {
	        for (int r = getJoueur().getMinR(); r < getJoueur().getMaxR(); r++)
	            for (int c = getJoueur().getMinC(); c < getJoueur().getMaxC(); c++)
	                getJoueur().getPoints()[r][c] = Constants.EMPTY;
	 
	        getJoueur().setOptions(new HashMap<>());
	        getJoueur().setCandidates(new ArrayList<Option>());
	        getJoueur().setDroites(new ArrayList<>());
	        getJoueur().setMinC(getJoueur().setMinR(18));
	        getJoueur().setMaxC(getJoueur().setMaxR(31));
	 
	        // cross
	        for (int r = 0; r < 10; r++)
	            for (int c = 0; c < 10; c++)
	                if ((getJoueur().getBasePoints()[r] & (1 << c)) != 0)
	                	getJoueur().getPoints()[20 + r][20 + c] = Constants.POINT;
	    }
	    
	    public void hints() {
	    	   for (Point p : getPossibleMoves()) {
	    		   joueur.getPoints()[p.y][p.x] |= Constants.HINT;
	    	   }
	    }
	    

		public Joueur getJoueur() {
			return joueur;
		}
	 
	 

}
