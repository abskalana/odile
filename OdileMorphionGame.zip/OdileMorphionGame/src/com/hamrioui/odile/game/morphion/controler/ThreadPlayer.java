package com.hamrioui.odile.game.morphion.controler;

import java.awt.Point;
import java.util.List;
import java.util.Random;

import com.hamrioui.odile.game.morphion.model.JeuStatus;
import com.hamrioui.odile.game.morphion.view.Plateau;

public class ThreadPlayer  extends Thread{
	
	private Plateau game;
	private GameControler controler;
	

	public ThreadPlayer(Plateau game, GameControler controler) {
		super();
		this.game = game;
		this.controler = controler;
	}

	public void run() {
           Random rand = new Random();
           while (true) {
               try {
                   if (game.getGameState() == JeuStatus.MACHINE) {
                       Thread.sleep(2000L);

                       List<Point> moves = controler.getPossibleMoves();
                       Point move = moves.get(rand.nextInt(moves.size()));
                       controler.calculateMove(move.y, move.x);
                       game.setComputerScore(game.getComputerScore() + 1);

                       if (controler.getPossibleMoves().isEmpty()) {
                    	   game.setGameState(JeuStatus.TERMINE);
                       } else {
                    	   game.setGameState(JeuStatus.HOMME);
                    	   game.setMessage("Joueur 1");
                       }
                       game.repaint();
                   }
                   Thread.sleep(100L);
               } catch (InterruptedException ignored) {
               }
           }
       }
	

}
