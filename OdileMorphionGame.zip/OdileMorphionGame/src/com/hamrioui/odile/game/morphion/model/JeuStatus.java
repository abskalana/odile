package com.hamrioui.odile.game.morphion.model;

public enum JeuStatus {
        COMMENCER, HOMME, MACHINE, TERMINE
}
