package com.hamrioui.odile.game.morphion.model;

import java.awt.Point;
import java.util.List;
import java.util.Map;


public class Joueur {
    
  
    private final int[] basePoints = {120, 72, 72, 975, 513, 513, 975, 72, 72, 120};
 
    private int cellSize;

	private int pointSize;

	private int halfCell;

	private int centerX;

	private int centerY;

	private int origX;

	private int origY;
    private int minC;

	private int minR;

	private int maxC;

	private int maxR;
 
    private int[][] points;
    private List<Segment> droites;
    private Map<Point, Option> options;
    private List<Option> candidates;
 
 
    public Joueur(int cs, int ps) {
        setCellSize(cs);
        setPointSize(ps);
        setHalfCell(cs / 2);
        setPoints(new int[50][50]);
        setMinC(setMinR(0));
        setMaxC(setMaxR(50));
       
    }
 
	public int getMinR() {
		return minR;
	}

	public int setMinR(int minR) {
		this.minR = minR;
		return minR;
	}

	public int getMaxR() {
		return maxR;
	}

	public int setMaxR(int maxR) {
		this.maxR = maxR;
		return maxR;
	}

	public int getMaxC() {
		return maxC;
	}

	public void setMaxC(int maxC) {
		this.maxC = maxC;
	}

	public int getMinC() {
		return minC;
	}

	public void setMinC(int minC) {
		this.minC = minC;
	}

	public List<Option> getCandidates() {
		return candidates;
	}

	public void setCandidates(List<Option> candidates) {
		this.candidates = candidates;
	}

	public int[][] getPoints() {
		return points;
	}

	public void setPoints(int[][] points) {
		this.points = points;
	}


	public Map<Point, Option> getOptions() {
		return options;
	}


	public void setOptions(Map<Point, Option> options) {
		this.options = options;
	}


	public List<Segment> getDroites() {
		return droites;
	}


	public void setDroites(List<Segment> droites) {
		this.droites = droites;
	}


	public int[] getBasePoints() {
		return basePoints;
	}






	public int getCenterX() {
		return centerX;
	}






	public void setCenterX(int centerX) {
		this.centerX = centerX;
	}






	public int getCenterY() {
		return centerY;
	}






	public void setCenterY(int centerY) {
		this.centerY = centerY;
	}






	public int getOrigY() {
		return origY;
	}






	public void setOrigY(int origY) {
		this.origY = origY;
	}






	public int getOrigX() {
		return origX;
	}






	public void setOrigX(int origX) {
		this.origX = origX;
	}






	public int getHalfCell() {
		return halfCell;
	}






	public void setHalfCell(int halfCell) {
		this.halfCell = halfCell;
	}






	public int getCellSize() {
		return cellSize;
	}






	public void setCellSize(int cellSize) {
		this.cellSize = cellSize;
	}






	public int getPointSize() {
		return pointSize;
	}






	public void setPointSize(int pointSize) {
		this.pointSize = pointSize;
	}
 
   
}