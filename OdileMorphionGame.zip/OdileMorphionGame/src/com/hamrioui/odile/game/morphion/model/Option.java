package com.hamrioui.odile.game.morphion.model;

import java.awt.Point;
import java.util.List;

public class Option {
    public int[] dir;
    public List<Point> points;

    public Option(List<Point> p, int[] d) {
        points = p;
        dir = d;
    }
    
}