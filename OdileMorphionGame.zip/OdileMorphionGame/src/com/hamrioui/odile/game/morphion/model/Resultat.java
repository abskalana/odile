package com.hamrioui.odile.game.morphion.model;

public enum Resultat {
	BON, MAUVAIS, VILAIN
}
