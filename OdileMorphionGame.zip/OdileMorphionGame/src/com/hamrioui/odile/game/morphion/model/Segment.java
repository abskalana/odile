package com.hamrioui.odile.game.morphion.model;

import java.awt.Point;

public class Segment {
    public final Point start, end;
    
    public Segment(Point p1, Point p2) {
        this.start = p1;
        this.end = p2;
    }
}
