package com.hamrioui.odile.game.morphion.utils;

public class Constants {
	
	public static final int EMPTY = 0;
	public static final int	POINT = 1;
	public static final int HORI = 2;
	public static final int VERT = 4;
	public static final int DIUP = 8;
	public static final int DIDO = 16;
	public static final int HORI_END = 32;
	public static final int VERT_END = 64;
	public static final int DIUP_END = 128;
	public static final int DIDO_END = 256;
	public static final int CAND = 512;
	public static final int ORIG = 1024;
	public static final int HINT = 2048;
}
