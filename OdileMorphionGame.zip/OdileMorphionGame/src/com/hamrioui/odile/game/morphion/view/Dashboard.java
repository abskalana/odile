package com.hamrioui.odile.game.morphion.view;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JFrame;

public class Dashboard extends JFrame {
 
   
	private static final long serialVersionUID = 1L;

	public Dashboard() {
        Container content = getContentPane();
        content.setLayout(new BorderLayout());
        Plateau gameSpace = new Plateau();
        content.add(gameSpace, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null);
    }
}