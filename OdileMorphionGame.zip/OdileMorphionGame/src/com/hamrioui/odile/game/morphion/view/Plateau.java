package com.hamrioui.odile.game.morphion.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.hamrioui.odile.game.morphion.controler.GameControler;
import com.hamrioui.odile.game.morphion.controler.ThreadPlayer;
import com.hamrioui.odile.game.morphion.model.Joueur;
import com.hamrioui.odile.game.morphion.model.Resultat;
import com.hamrioui.odile.game.morphion.model.JeuStatus;
import com.hamrioui.odile.game.morphion.utils.Constants;

public class Plateau extends JPanel {
	
	private static final long serialVersionUID = 1L;
		private JeuStatus gameState = JeuStatus.COMMENCER;
		private GameControler  controler;
	    private String message = "Jouer";
	    int score;
		private int computerScore;
	    private Font scoreFont;
	 
	    public Plateau() {
	        setPreferredSize(new Dimension(500, 500));
	        setBackground(Color.CYAN);
	 
	        setFont(new Font("SansSerif", Font.BOLD, 16));
	        scoreFont = new Font("SansSerif", Font.BOLD, 12);
	 
	        controler = new GameControler(new Joueur(35, 9));
	        controler.start();
	        	
	 
	        addMouseListener(new MouseAdapter() {
	            @Override
	            public void mousePressed(MouseEvent e) {
	                switch (getGameState()) {
	                    case COMMENCER:
	                        setGameState(JeuStatus.HOMME);
	                        setMessage("Joueur 1");
	                        score = setComputerScore(0);
	                        controler.start();
	                        break;
	                    case HOMME:
	                        if (SwingUtilities.isRightMouseButton(e))
	                        	controler.hints();
	                        else {
	                           Resultat res = controler.move(e.getX(), e.getY());
	                            if (res == Resultat.BON) {
	                                score++;
	 
	                                if (controler.getPossibleMoves().isEmpty())
	                                    setGameState(JeuStatus.TERMINE);
	                                else {
	                                    setGameState(JeuStatus.MACHINE);
	                                    setMessage("Joueur 2.");
	                                }
	                            }
	                        }
	                        break;
	                }
	                repaint();
	            }
	        });
	 
	        new ThreadPlayer(Plateau.this,controler).start();
	    }
	 
	 
	    @Override
	    public void paintComponent(Graphics gg) {
	        super.paintComponent(gg);
	        Graphics2D g = (Graphics2D) gg;
	        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	                RenderingHints.VALUE_ANTIALIAS_ON);
	 
	        controler.draw(g, getWidth(), getHeight());
	 
	        if (getGameState() == JeuStatus.TERMINE) {
	            setMessage("Aucun deplacement possible ");
	            if (score > getComputerScore())
	                setMessage(getMessage() + "You win. ");
	            else if (getComputerScore() > score)
	                setMessage(getMessage() + "Joeur 2 a gagn� ");
	            else
	                setMessage(getMessage() + " ");
	            setMessage(getMessage() + "Nouveau jeu.");
	            setGameState(JeuStatus.COMMENCER);
	        }
	 
	        g.setColor(Color.white);
	        g.fillRect(0, getHeight() - 50, getWidth(), getHeight() - 50);
	 
	        g.setColor(Color.lightGray);
	        g.setStroke(new BasicStroke(1));
	        g.drawLine(0, getHeight() - 50, getWidth(), getHeight() - 50);
	 
	        g.setColor(Color.darkGray);
	 
	        g.setFont(getFont());
	        g.drawString(getMessage(), 20, getHeight() - 18);
	 
	        g.setFont(scoreFont);
	        String s1 = "Joueur 1 " + String.valueOf(score);
	        g.drawString(s1, getWidth() - 180, getHeight() - 20);
	 
	        String s2 = "Joueur 2 " + String.valueOf(getComputerScore());
	        g.drawString(s2, getWidth() - 100, getHeight() - 20);
	    }

		public JeuStatus getGameState() {
			return gameState;
		}

		public void setGameState(JeuStatus gameState) {
			this.gameState = gameState;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		public int getComputerScore() {
			return computerScore;
		}

		public int setComputerScore(int computerScore) {
			this.computerScore = computerScore;
			return computerScore;
		}
	    
	    
	  
	    
	}



