package com.hamrioui.odile.game.morphion;

import javax.swing.JFrame;

import com.hamrioui.odile.game.morphion.view.DashboardGame;

public class Application {

    public static void main(String[] args) {
    	DashboardGame dashboardGame = new DashboardGame();
    	dashboardGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	dashboardGame.setTitle("Jeu de morphion");
    	dashboardGame.setVisible(true);
    }
}