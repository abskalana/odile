package com.hamrioui.odile.game.morphion.model;

import java.awt.Point;

public class Droite {
    public final Point start, end;
    
    public Droite(Point p1, Point p2) {
        this.start = p1;
        this.end = p2;
    }
}
