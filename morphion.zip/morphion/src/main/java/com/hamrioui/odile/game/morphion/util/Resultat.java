package com.hamrioui.odile.game.morphion.util;

public enum Resultat {
	BON, MAUVAIS, VILAIN
}
