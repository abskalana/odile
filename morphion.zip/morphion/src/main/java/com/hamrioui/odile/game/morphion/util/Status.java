package com.hamrioui.odile.game.morphion.util;

public enum Status {
        COMMENCER, HUMAIN, MACHINE, TERMINE
}
