package com.hamrioui.odile.game.morphion.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Random;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import com.hamrioui.odile.game.morphion.controler.Player;
import com.hamrioui.odile.game.morphion.util.Resultat;
import com.hamrioui.odile.game.morphion.util.Status;

public class GameSpace extends JPanel {
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		Status gameState = Status.COMMENCER;
	    Player player;
	    String message = "Jouer";
	    int score, computerScore;
	    Font scoreFont;
	 
	    public GameSpace() {
	        setPreferredSize(new Dimension(500, 500));
	        setBackground(Color.CYAN);
	 
	        setFont(new Font("SansSerif", Font.BOLD, 16));
	        scoreFont = new Font("SansSerif", Font.BOLD, 12);
	 
	        player = new Player(35, 9);
	 
	        addMouseListener(new MouseAdapter() {
	            @Override
	            public void mousePressed(MouseEvent e) {
	                switch (gameState) {
	                    case COMMENCER:
	                        gameState = Status.HUMAIN;
	                        message = "Joueur 1";
	                        score = computerScore = 0;
	                        player.newGame();
	                        break;
	                    case HUMAIN:
	                        if (SwingUtilities.isRightMouseButton(e))
	                            player.showHints();
	                        else {
	                           Resultat res = player.playerMove(e.getX(), e.getY());
	                            if (res == Resultat.BON) {
	                                score++;
	 
	                                if (player.possibleMoves().isEmpty())
	                                    gameState = Status.TERMINE;
	                                else {
	                                    gameState = Status.MACHINE;
	                                    message = "Joueur 2.";
	                                }
	                            }
	                        }
	                        break;
	                }
	                repaint();
	            }
	        });
	 
	        start();
	    }
	 
	    public final void start() {
	        new Thread(new Runnable() {
	            @Override
	            public void run() {
	                Random rand = new Random();
	                while (true) {
	                    try {
	                        if (gameState == Status.MACHINE) {
	                            Thread.sleep(1500L);
	 
	                            List<Point> moves = player.possibleMoves();
	                            Point move = moves.get(rand.nextInt(moves.size()));
	                            player.computerMove(move.y, move.x);
	                            computerScore++;
	 
	                            if (player.possibleMoves().isEmpty()) {
	                                gameState = Status.TERMINE;
	                            } else {
	                                gameState = Status.HUMAIN;
	                                message = "Joueur 1";
	                            }
	                            repaint();
	                        }
	                        Thread.sleep(100L);
	                    } catch (InterruptedException ignored) {
	                    }
	                }
	            }
	        }).start();
	    }
	 
	    @Override
	    public void paintComponent(Graphics gg) {
	        super.paintComponent(gg);
	        Graphics2D g = (Graphics2D) gg;
	        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
	                RenderingHints.VALUE_ANTIALIAS_ON);
	 
	        player.draw(g, getWidth(), getHeight());
	 
	        if (gameState == Status.TERMINE) {
	            message = "Aucun deplacement possible ";
	            if (score > computerScore)
	                message += "You win. ";
	            else if (computerScore > score)
	                message += "Joeur 2 a gagn� ";
	            else
	                message += " ";
	            message += "Nouveau jeu.";
	            gameState = Status.COMMENCER;
	        }
	 
	        g.setColor(Color.white);
	        g.fillRect(0, getHeight() - 50, getWidth(), getHeight() - 50);
	 
	        g.setColor(Color.lightGray);
	        g.setStroke(new BasicStroke(1));
	        g.drawLine(0, getHeight() - 50, getWidth(), getHeight() - 50);
	 
	        g.setColor(Color.darkGray);
	 
	        g.setFont(getFont());
	        g.drawString(message, 20, getHeight() - 18);
	 
	        g.setFont(scoreFont);
	        String s1 = "Joueur 1 " + String.valueOf(score);
	        g.drawString(s1, getWidth() - 180, getHeight() - 20);
	 
	        String s2 = "Joueur 2 " + String.valueOf(computerScore);
	        g.drawString(s2, getWidth() - 100, getHeight() - 20);
	    }
	}

